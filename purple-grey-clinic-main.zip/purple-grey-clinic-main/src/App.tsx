
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/context/AuthContext";
import { HospitalDataProvider } from "@/context/HospitalDataContext";
import Home from "./pages/Home";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Dashboard from "./pages/Dashboard";
import Appointments from "./pages/patient/Appointments";
import HealthRecords from "./pages/patient/HealthRecords";
import Suggestions from "./pages/patient/Suggestions";
import Patients from "./pages/doctor/Patients";
import Shifts from "./pages/doctor/Shifts";
import Management from "./pages/admin/Management";
import UsersPage from "./pages/admin/Users";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <HospitalDataProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<Home />} />
              <Route path="/login" element={<Login />} />
              <Route path="/signup" element={<Signup />} />

              {/* Protected Routes */}
              <Route path="/dashboard" element={<Dashboard />} />
              
              {/* Patient Routes */}
              <Route path="/dashboard/appointments" element={<Appointments />} />
              <Route path="/dashboard/health-records" element={<HealthRecords />} />
              <Route path="/dashboard/suggestions" element={<Suggestions />} />
              
              {/* Doctor Routes */}
              <Route path="/dashboard/patients" element={<Patients />} />
              <Route path="/dashboard/shifts" element={<Shifts />} />
              
              {/* Admin Routes */}
              <Route path="/dashboard/management" element={<Management />} />
              <Route path="/dashboard/users" element={<UsersPage />} />
              
              {/* Catch-all */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </HospitalDataProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
