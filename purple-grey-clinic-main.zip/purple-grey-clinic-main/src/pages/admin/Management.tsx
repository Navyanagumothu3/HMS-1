
import React from 'react';
import { useHospitalData } from '@/context/HospitalDataContext';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Hospital, Users, Calendar } from 'lucide-react';
import { 
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, 
  Tooltip as RechartsTooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell 
} from 'recharts';

// Mock data for hospital statistics
const appointmentData = [
  { month: 'Jan', appointments: 65 },
  { month: 'Feb', appointments: 59 },
  { month: 'Mar', appointments: 80 },
  { month: 'Apr', appointments: 81 },
  { month: 'May', appointments: 56 },
  { month: 'Jun', appointments: 55 },
  { month: 'Jul', appointments: 40 },
];

const departmentData = [
  { name: 'Cardiology', value: 30 },
  { name: 'Neurology', value: 25 },
  { name: 'Dermatology', value: 15 },
  { name: 'Pediatrics', value: 20 },
  { name: 'Orthopedics', value: 10 },
];

const doctorPerformanceData = [
  { name: 'Dr. Jane Smith', appointments: 45, satisfaction: 4.8 },
  { name: 'Dr. Robert Johnson', appointments: 38, satisfaction: 4.5 },
  { name: 'Dr. Sarah Chen', appointments: 42, satisfaction: 4.7 },
  { name: 'Dr. Michael Lee', appointments: 30, satisfaction: 4.6 },
  { name: 'Dr. Emily Wilson', appointments: 35, satisfaction: 4.4 },
];

const COLORS = ['#9b87f5', '#D6BCFA', '#F1F1F1', '#C8C8C9', '#F1F0FB'];

const Management = () => {
  const { doctors, appointments } = useHospitalData();

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Hospital Management</h1>
        <p className="text-gray-600">Overview and management of hospital operations</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card className="dashboard-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground">Total Doctors</p>
                <h2 className="text-3xl font-bold text-hospital-purple">{doctors.length}</h2>
              </div>
              <div className="w-12 h-12 bg-hospital-purple/10 rounded-full flex items-center justify-center">
                <Users className="h-6 w-6 text-hospital-purple" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="dashboard-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground">Total Patients</p>
                <h2 className="text-3xl font-bold text-hospital-purple">12</h2>
              </div>
              <div className="w-12 h-12 bg-hospital-purple/10 rounded-full flex items-center justify-center">
                <Users className="h-6 w-6 text-hospital-purple" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="dashboard-card">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground">Total Appointments</p>
                <h2 className="text-3xl font-bold text-hospital-purple">{appointments.length}</h2>
              </div>
              <div className="w-12 h-12 bg-hospital-purple/10 rounded-full flex items-center justify-center">
                <Calendar className="h-6 w-6 text-hospital-purple" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview">
        <TabsList className="mb-6">
          <TabsTrigger value="overview">Hospital Overview</TabsTrigger>
          <TabsTrigger value="departments">Departments</TabsTrigger>
          <TabsTrigger value="doctors">Doctor Performance</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview">
          <Card className="dashboard-card">
            <CardHeader>
              <CardTitle>Hospital Operations Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={appointmentData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <RechartsTooltip />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="appointments"
                      stroke="#9b87f5"
                      activeDot={{ r: 8 }}
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              <p className="text-center text-muted-foreground mt-4">
                Monthly appointment trends
              </p>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="departments">
          <Card className="dashboard-card">
            <CardHeader>
              <CardTitle>Department Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px] flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={departmentData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={150}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {departmentData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <RechartsTooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <p className="text-center text-muted-foreground mt-4">
                Distribution of appointments by department
              </p>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="doctors">
          <Card className="dashboard-card">
            <CardHeader>
              <CardTitle>Doctor Performance Metrics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={doctorPerformanceData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <RechartsTooltip />
                    <Legend />
                    <Bar dataKey="appointments" fill="#9b87f5" />
                    <Bar dataKey="satisfaction" fill="#D6BCFA" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <p className="text-center text-muted-foreground mt-4">
                Doctor performance by appointments and patient satisfaction (out of 5)
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </DashboardLayout>
  );
};

export default Management;
