
import React from 'react';
import { useHospitalData } from '@/context/HospitalDataContext';
import { useAuth } from '@/context/AuthContext';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText } from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { format, parseISO } from 'date-fns';

const HealthRecords = () => {
  const { user } = useAuth();
  const { healthRecords, doctors } = useHospitalData();

  // Filter health records for the current patient
  const patientRecords = healthRecords.filter(record => record.patientId === user?.id);

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Health Records</h1>
        <p className="text-gray-600">View your medical history and records</p>
      </div>

      <Card className="dashboard-card">
        <CardHeader className="pb-2">
          <div className="flex items-center gap-3">
            <FileText className="h-6 w-6 text-hospital-purple" />
            <CardTitle>Your Medical Records</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          {patientRecords.length > 0 ? (
            <Accordion type="single" collapsible className="w-full">
              {patientRecords.map((record, index) => {
                const doctor = doctors.find(d => d.id === record.doctorId);
                return (
                  <AccordionItem key={record.id} value={`item-${index}`}>
                    <AccordionTrigger className="hover:no-underline">
                      <div className="flex flex-col items-start text-left">
                        <div className="text-base font-medium">{record.diagnosis}</div>
                        <div className="text-sm text-muted-foreground">
                          {record.date} • {doctor?.name}
                        </div>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-4">
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <h4 className="text-sm font-semibold mb-1">Doctor</h4>
                            <p>{doctor?.name}</p>
                            <p className="text-sm text-muted-foreground">{doctor?.specialization}</p>
                          </div>
                          <div>
                            <h4 className="text-sm font-semibold mb-1">Date</h4>
                            <p>{record.date}</p>
                          </div>
                        </div>

                        <div>
                          <h4 className="text-sm font-semibold mb-1">Diagnosis</h4>
                          <p>{record.diagnosis}</p>
                        </div>

                        <div>
                          <h4 className="text-sm font-semibold mb-1">Prescription</h4>
                          <div className="bg-hospital-softgrey p-3 rounded-md">
                            <p>{record.prescription}</p>
                          </div>
                        </div>

                        <div>
                          <h4 className="text-sm font-semibold mb-1">Notes</h4>
                          <p>{record.notes}</p>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                );
              })}
            </Accordion>
          ) : (
            <div className="text-center py-12">
              <h3 className="font-medium text-xl mb-2">No health records found</h3>
              <p className="text-gray-500">Your medical history will appear here after your appointments.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </DashboardLayout>
  );
};

export default HealthRecords;
