
import React, { useState } from 'react';
import { useHospitalData, Doctor } from '@/context/HospitalDataContext';
import { useAuth } from '@/context/AuthContext';
import DashboardLayout from '@/components/DashboardLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar as CalendarIcon } from 'lucide-react';
import { Calendar } from '@/components/ui/calendar';
import { format, addDays, isWeekend, isSameDay, parseISO } from 'date-fns';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';

const Appointments = () => {
  const { user } = useAuth();
  const { doctors, appointments, addAppointment, updatePaymentStatus } = useHospitalData();
  
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<string>('credit');
  const [cardNumber, setCardNumber] = useState<string>('');
  const [expiryDate, setExpiryDate] = useState<string>('');
  const [cvv, setCvv] = useState<string>('');
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState<boolean>(false);
  const [currentAppointment, setCurrentAppointment] = useState<any | null>(null);

  // Get user's appointments
  const userAppointments = appointments.filter(app => app.patientId === user?.id);

  // Function to get available slots for the selected date and doctor
  const getAvailableSlots = () => {
    if (!selectedDoctor || !selectedDate) return [];
    
    // Get day of week
    const dayOfWeek = format(selectedDate, 'EEEE');
    
    // Find available slots for this day
    const dayAvailability = selectedDoctor.availability.find(
      a => a.day.toLowerCase() === dayOfWeek.toLowerCase()
    );
    
    if (!dayAvailability) return [];
    
    // Filter out slots that are already booked
    const bookedSlots = appointments
      .filter(app => app.doctorId === selectedDoctor.id && app.date === format(selectedDate, 'yyyy-MM-dd'))
      .map(app => app.time);
    
    return dayAvailability.slots.filter(slot => !bookedSlots.includes(slot));
  };

  // Handle date selection - only allow future dates and exclude weekends
  const handleDateSelect = (date: Date | undefined) => {
    setSelectedDate(date);
    setSelectedTime(null); // Reset time selection when date changes
  };

  // Handle appointment booking
  const handleBookAppointment = () => {
    if (!user || !selectedDoctor || !selectedDate || !selectedTime) {
      toast.error('Please select all required fields');
      return;
    }
    
    const newAppointment = {
      patientId: user.id,
      doctorId: selectedDoctor.id,
      date: format(selectedDate, 'yyyy-MM-dd'),
      time: selectedTime,
      status: 'scheduled' as const,
      paymentStatus: 'pending' as const,
      fee: selectedDoctor.fee,
    };
    
    addAppointment(newAppointment);
    setCurrentAppointment(newAppointment);
    setIsPaymentDialogOpen(true);
  };

  // Handle payment processing
  const handlePayment = () => {
    if (!currentAppointment) return;
    
    if (paymentMethod === 'credit' && (!cardNumber || !expiryDate || !cvv)) {
      toast.error('Please fill in all payment details');
      return;
    }
    
    // In a real app, we would process payment here
    // For now, we'll just simulate a successful payment
    
    updatePaymentStatus(currentAppointment.id, 'paid');
    setIsPaymentDialogOpen(false);
    
    // Reset form
    setSelectedDoctor(null);
    setSelectedDate(undefined);
    setSelectedTime(null);
    setCardNumber('');
    setExpiryDate('');
    setCvv('');
    
    toast.success('Appointment booked successfully!');
  };

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Appointments</h1>
        <p className="text-gray-600">Book and manage your medical appointments</p>
      </div>
      
      <Tabs defaultValue="book">
        <TabsList className="mb-6">
          <TabsTrigger value="book">Book Appointment</TabsTrigger>
          <TabsTrigger value="upcoming">Your Appointments</TabsTrigger>
        </TabsList>
        
        <TabsContent value="book">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Step 1: Select Doctor */}
            <Card className="dashboard-card">
              <CardHeader>
                <CardTitle>Select a Doctor</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {doctors.map(doctor => (
                    <div 
                      key={doctor.id}
                      className={`p-4 border rounded-lg cursor-pointer transition-all ${
                        selectedDoctor?.id === doctor.id
                          ? 'border-hospital-purple bg-hospital-softgrey'
                          : 'border-gray-200 hover:border-hospital-purple'
                      }`}
                      onClick={() => setSelectedDoctor(doctor)}
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-16 h-16 rounded-full overflow-hidden">
                          <img 
                            src={doctor.image} 
                            alt={doctor.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div>
                          <h3 className="font-medium">{doctor.name}</h3>
                          <p className="text-sm text-gray-500">{doctor.specialization}</p>
                          <p className="text-sm text-gray-500">{doctor.experience} years exp</p>
                          <p className="text-sm font-medium text-hospital-purple">${doctor.fee}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            {/* Steps 2 & 3: Select Date & Time */}
            <Card className="dashboard-card">
              <CardHeader>
                <CardTitle>Select Date & Time</CardTitle>
              </CardHeader>
              <CardContent>
                {selectedDoctor ? (
                  <div className="space-y-6">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={`w-full justify-start text-left font-normal ${!selectedDate ? 'text-muted-foreground' : ''}`}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {selectedDate ? format(selectedDate, 'PPP') : <span>Pick a date</span>}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0 pointer-events-auto">
                        <Calendar
                          mode="single"
                          selected={selectedDate}
                          onSelect={handleDateSelect}
                          disabled={(date) => {
                            // Disable past dates, weekends
                            const today = new Date();
                            today.setHours(0, 0, 0, 0);
                            return date < today || isWeekend(date);
                          }}
                          className="p-3"
                        />
                      </PopoverContent>
                    </Popover>
                    
                    {selectedDate && (
                      <div className="space-y-4">
                        <h3 className="font-medium">Available Time Slots</h3>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                          {getAvailableSlots().length > 0 ? (
                            getAvailableSlots().map((slot, index) => (
                              <Button
                                key={index}
                                variant="outline"
                                className={`${selectedTime === slot ? 'bg-hospital-purple text-white' : ''}`}
                                onClick={() => setSelectedTime(slot)}
                              >
                                {slot}
                              </Button>
                            ))
                          ) : (
                            <p className="col-span-3 text-center text-muted-foreground py-4">
                              No available slots for this date
                            </p>
                          )}
                        </div>
                      </div>
                    )}
                    
                    <Button 
                      className="w-full hospital-btn-primary"
                      disabled={!selectedDoctor || !selectedDate || !selectedTime}
                      onClick={handleBookAppointment}
                    >
                      Book Appointment
                    </Button>
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-40">
                    <p className="text-muted-foreground">Please select a doctor first</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="upcoming">
          <div className="space-y-6">
            {userAppointments.length > 0 ? (
              userAppointments.map(appointment => {
                const doctor = doctors.find(d => d.id === appointment.doctorId);
                return (
                  <Card key={appointment.id} className="dashboard-card">
                    <CardContent className="pt-6">
                      <div className="flex flex-col md:flex-row md:items-center justify-between">
                        <div className="flex items-center gap-4 mb-4 md:mb-0">
                          <div className="w-16 h-16 rounded-full overflow-hidden">
                            <img 
                              src={doctor?.image || 'https://via.placeholder.com/150'} 
                              alt={doctor?.name}
                              className="w-full h-full object-cover"
                            />
                          </div>
                          <div>
                            <h3 className="font-medium">{doctor?.name}</h3>
                            <p className="text-sm text-gray-500">{doctor?.specialization}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-sm text-gray-700">
                                {appointment.date} • {appointment.time}
                              </span>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex flex-col gap-2">
                          <div className="flex gap-2 flex-wrap">
                            <span className={`text-xs px-2 py-1 rounded-full ${
                              appointment.status === 'scheduled' ? 'bg-blue-100 text-blue-800' :
                              appointment.status === 'completed' ? 'bg-green-100 text-green-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                            </span>
                            <span className={`text-xs px-2 py-1 rounded-full ${
                              appointment.paymentStatus === 'paid' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                            }`}>
                              {appointment.paymentStatus === 'paid' ? 'Paid' : 'Payment Pending'}
                            </span>
                          </div>
                          
                          {appointment.paymentStatus === 'pending' && (
                            <Button 
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setCurrentAppointment(appointment);
                                setIsPaymentDialogOpen(true);
                              }}
                            >
                              Pay Now
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            ) : (
              <div className="text-center py-12">
                <h3 className="font-medium text-xl mb-2">No appointments found</h3>
                <p className="text-gray-500 mb-6">You haven't booked any appointments yet.</p>
                <Button className="hospital-btn-primary" onClick={() => {
                  const bookTab = document.querySelector('[data-value="book"]');
                  if (bookTab) {
                    (bookTab as HTMLElement).click();
                  }
                }}>
                  Book Your First Appointment
                </Button>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Payment Dialog */}
      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Payment for Appointment</DialogTitle>
            <DialogDescription>
              Complete payment to confirm your appointment with {
                doctors.find(d => d.id === currentAppointment?.doctorId)?.name
              }
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Doctor Fee:</span>
              <span className="font-medium">${currentAppointment?.fee}</span>
            </div>
            
            <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="credit" id="credit" />
                <Label htmlFor="credit">Credit/Debit Card</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="insurance" id="insurance" />
                <Label htmlFor="insurance">Insurance</Label>
              </div>
            </RadioGroup>
            
            {paymentMethod === 'credit' && (
              <div className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="cardNumber">Card Number</Label>
                  <Input
                    id="cardNumber"
                    placeholder="1234 5678 9012 3456"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="expiryDate">Expiry Date</Label>
                    <Input
                      id="expiryDate"
                      placeholder="MM/YY"
                      value={expiryDate}
                      onChange={(e) => setExpiryDate(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cvv">CVV</Label>
                    <Input
                      id="cvv"
                      placeholder="123"
                      value={cvv}
                      onChange={(e) => setCvv(e.target.value)}
                    />
                  </div>
                </div>
              </div>
            )}
            
            {paymentMethod === 'insurance' && (
              <div className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="insuranceNumber">Insurance Policy Number</Label>
                  <Input
                    id="insuranceNumber"
                    placeholder="INS-12345678"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="memberName">Member Name</Label>
                  <Input
                    id="memberName"
                    placeholder="John Doe"
                  />
                </div>
              </div>
            )}
          </div>
          
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsPaymentDialogOpen(false)}>
              Cancel
            </Button>
            <Button type="button" className="hospital-btn-primary" onClick={handlePayment}>
              Pay ${currentAppointment?.fee}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
};

export default Appointments;
