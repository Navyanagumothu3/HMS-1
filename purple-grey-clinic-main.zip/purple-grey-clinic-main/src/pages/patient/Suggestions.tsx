
import React from 'react';
import { useHospitalData } from '@/context/HospitalDataContext';
import { useAuth } from '@/context/AuthContext';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BookOpen } from 'lucide-react';

const Suggestions = () => {
  const { user } = useAuth();
  const { suggestions, doctors } = useHospitalData();

  // Filter suggestions for the current patient
  const patientSuggestions = suggestions.filter(suggestion => suggestion.patientId === user?.id);

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Doctor Suggestions</h1>
        <p className="text-gray-600">Recommendations and advice from your doctors</p>
      </div>

      <Card className="dashboard-card">
        <CardHeader className="pb-2">
          <div className="flex items-center gap-3">
            <BookOpen className="h-6 w-6 text-hospital-purple" />
            <CardTitle>Your Doctor's Recommendations</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          {patientSuggestions.length > 0 ? (
            <div className="space-y-6">
              {patientSuggestions.map(suggestion => {
                const doctor = doctors.find(d => d.id === suggestion.doctorId);
                return (
                  <div key={suggestion.id} className="border-b pb-4">
                    <div className="flex items-start gap-3 mb-3">
                      <div className="w-12 h-12 rounded-full overflow-hidden flex-shrink-0">
                        <img 
                          src={doctor?.image || 'https://via.placeholder.com/150'} 
                          alt={doctor?.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <h3 className="font-medium">{doctor?.name}</h3>
                        <p className="text-sm text-gray-500">{doctor?.specialization}</p>
                        <p className="text-xs text-gray-400">{suggestion.date}</p>
                      </div>
                    </div>
                    <div className="pl-15 ml-12">
                      <p className="text-gray-700">{suggestion.message}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12">
              <h3 className="font-medium text-xl mb-2">No suggestions found</h3>
              <p className="text-gray-500">Your doctor's recommendations will appear here after consultations.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </DashboardLayout>
  );
};

export default Suggestions;
