
import React, { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Clock, Plus, Trash2 } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

// Define the Shift type
interface Shift {
  id: string;
  day: string;
  startTime: string;
  endTime: string;
}

const weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const timeSlots = [
  '8:00 AM', '9:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', 
  '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM', '5:00 PM', '6:00 PM'
];

const Shifts = () => {
  const { user } = useAuth();

  // Mock data for doctor shifts
  const [shifts, setShifts] = useState<Shift[]>([
    { id: '1', day: 'Monday', startTime: '9:00 AM', endTime: '12:00 PM' },
    { id: '2', day: 'Monday', startTime: '2:00 PM', endTime: '5:00 PM' },
    { id: '3', day: 'Wednesday', startTime: '9:00 AM', endTime: '12:00 PM' },
    { id: '4', day: 'Wednesday', startTime: '2:00 PM', endTime: '5:00 PM' },
    { id: '5', day: 'Friday', startTime: '10:00 AM', endTime: '1:00 PM' },
    { id: '6', day: 'Friday', startTime: '3:00 PM', endTime: '6:00 PM' },
  ]);

  const [isAddShiftDialogOpen, setIsAddShiftDialogOpen] = useState(false);
  const [newShift, setNewShift] = useState<{ day: string; startTime: string; endTime: string }>({
    day: '',
    startTime: '',
    endTime: '',
  });

  // Function to add a new shift
  const handleAddShift = () => {
    const { day, startTime, endTime } = newShift;
    
    if (!day || !startTime || !endTime) {
      toast.error('Please select all fields');
      return;
    }
    
    if (startTime === endTime) {
      toast.error('Start and end time cannot be the same');
      return;
    }
    
    const startTimeIndex = timeSlots.indexOf(startTime);
    const endTimeIndex = timeSlots.indexOf(endTime);
    
    if (startTimeIndex >= endTimeIndex) {
      toast.error('End time must be after start time');
      return;
    }
    
    // Check for overlapping shifts
    const sameDayShifts = shifts.filter(shift => shift.day === day);
    const isOverlapping = sameDayShifts.some(shift => {
      const existingStartIndex = timeSlots.indexOf(shift.startTime);
      const existingEndIndex = timeSlots.indexOf(shift.endTime);
      
      return (
        (startTimeIndex >= existingStartIndex && startTimeIndex < existingEndIndex) ||
        (endTimeIndex > existingStartIndex && endTimeIndex <= existingEndIndex) ||
        (startTimeIndex <= existingStartIndex && endTimeIndex >= existingEndIndex)
      );
    });
    
    if (isOverlapping) {
      toast.error('This shift overlaps with an existing shift');
      return;
    }
    
    const newShiftRecord = {
      id: `${shifts.length + 1}`,
      day,
      startTime,
      endTime,
    };
    
    setShifts([...shifts, newShiftRecord]);
    setIsAddShiftDialogOpen(false);
    resetShiftForm();
    toast.success('Shift added successfully');
  };

  // Function to delete a shift
  const handleDeleteShift = (shiftId: string) => {
    setShifts(shifts.filter(shift => shift.id !== shiftId));
    toast.success('Shift deleted successfully');
  };

  // Reset shift form
  const resetShiftForm = () => {
    setNewShift({
      day: '',
      startTime: '',
      endTime: '',
    });
  };

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Shift Management</h1>
        <p className="text-gray-600">Manage your working hours and availability</p>
      </div>

      <Card className="dashboard-card">
        <CardHeader className="pb-2">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              <Clock className="h-6 w-6 text-hospital-purple" />
              <CardTitle>Your Shifts</CardTitle>
            </div>
            <Button onClick={() => setIsAddShiftDialogOpen(true)} className="hospital-btn-primary">
              <Plus className="h-4 w-4 mr-2" />
              Add Shift
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Day</TableHead>
                <TableHead>Start Time</TableHead>
                <TableHead>End Time</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {shifts.length > 0 ? (
                shifts.map(shift => (
                  <TableRow key={shift.id}>
                    <TableCell className="font-medium">{shift.day}</TableCell>
                    <TableCell>{shift.startTime}</TableCell>
                    <TableCell>{shift.endTime}</TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                        onClick={() => handleDeleteShift(shift.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={4} className="text-center py-4">
                    No shifts scheduled. Click "Add Shift" to create your work schedule.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      {/* Add Shift Dialog */}
      <Dialog open={isAddShiftDialogOpen} onOpenChange={setIsAddShiftDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add New Shift</DialogTitle>
            <DialogDescription>
              Set your availability for patient appointments
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label htmlFor="day" className="text-sm font-medium">
                Day
              </label>
              <Select 
                value={newShift.day}
                onValueChange={(value) => setNewShift({ ...newShift, day: value })}
              >
                <SelectTrigger id="day">
                  <SelectValue placeholder="Select day" />
                </SelectTrigger>
                <SelectContent>
                  {weekDays.map((day) => (
                    <SelectItem key={day} value={day}>
                      {day}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label htmlFor="startTime" className="text-sm font-medium">
                Start Time
              </label>
              <Select
                value={newShift.startTime}
                onValueChange={(value) => setNewShift({ ...newShift, startTime: value })}
              >
                <SelectTrigger id="startTime">
                  <SelectValue placeholder="Select start time" />
                </SelectTrigger>
                <SelectContent>
                  {timeSlots.map((time) => (
                    <SelectItem key={time} value={time}>
                      {time}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <label htmlFor="endTime" className="text-sm font-medium">
                End Time
              </label>
              <Select
                value={newShift.endTime}
                onValueChange={(value) => setNewShift({ ...newShift, endTime: value })}
              >
                <SelectTrigger id="endTime">
                  <SelectValue placeholder="Select end time" />
                </SelectTrigger>
                <SelectContent>
                  {timeSlots.map((time) => (
                    <SelectItem key={time} value={time}>
                      {time}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsAddShiftDialogOpen(false)}>
              Cancel
            </Button>
            <Button type="button" className="hospital-btn-primary" onClick={handleAddShift}>
              Add Shift
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
};

export default Shifts;
