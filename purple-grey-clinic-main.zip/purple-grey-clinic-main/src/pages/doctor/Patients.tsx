
import React from 'react';
import { useHospitalData } from '@/context/HospitalDataContext';
import { useAuth } from '@/context/AuthContext';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TabsContent, Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Users, Calendar, FileText } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from '@/components/ui/textarea';
import { useState } from 'react';
import { toast } from 'sonner';

const Patients = () => {
  const { user } = useAuth();
  const { appointments, updateAppointmentStatus, addHealthRecord, addSuggestion } = useHospitalData();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [isRecordDialogOpen, setIsRecordDialogOpen] = useState(false);
  const [isSuggestionDialogOpen, setIsSuggestionDialogOpen] = useState(false);
  const [selectedPatientId, setSelectedPatientId] = useState<string | null>(null);
  const [diagnosis, setDiagnosis] = useState('');
  const [prescription, setPrescription] = useState('');
  const [notes, setNotes] = useState('');
  const [suggestion, setSuggestion] = useState('');

  // Filter appointments for this doctor
  const doctorAppointments = appointments.filter(app => app.doctorId === user?.id);

  // Get unique patients
  const uniquePatientIds = Array.from(new Set(doctorAppointments.map(app => app.patientId)));
  const patients = uniquePatientIds.map(patientId => {
    const patientAppointments = doctorAppointments.filter(app => app.patientId === patientId);
    const latestAppointment = patientAppointments.reduce((latest, current) => {
      return new Date(current.date) > new Date(latest.date) ? current : latest;
    }, patientAppointments[0]);
    
    return {
      id: patientId,
      appointmentCount: patientAppointments.length,
      lastVisit: latestAppointment.date,
      nextAppointment: patientAppointments.find(app => app.status === 'scheduled')?.date || 'None',
    };
  });

  // Filter upcoming appointments (for today's appointments tab)
  const todayAppointments = doctorAppointments.filter(app => 
    app.status === 'scheduled' && app.date === new Date().toISOString().split('T')[0]
  );

  // Filter patients by search term
  const filteredPatients = patients.filter(patient =>
    patient.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Handle marking appointment as completed
  const completeAppointment = (appointmentId: string) => {
    updateAppointmentStatus(appointmentId, 'completed');
    toast.success('Appointment marked as completed');
  };

  // Handle adding health record
  const handleAddRecord = () => {
    if (!selectedPatientId || !user || !diagnosis) {
      toast.error('Please fill in all required fields');
      return;
    }

    addHealthRecord({
      patientId: selectedPatientId,
      doctorId: user.id,
      date: new Date().toISOString().split('T')[0],
      diagnosis,
      prescription,
      notes,
    });

    setIsRecordDialogOpen(false);
    resetFormFields();
    toast.success('Health record added successfully');
  };

  // Handle adding suggestion
  const handleAddSuggestion = () => {
    if (!selectedPatientId || !user || !suggestion) {
      toast.error('Please enter a suggestion');
      return;
    }

    addSuggestion({
      patientId: selectedPatientId,
      doctorId: user.id,
      date: new Date().toISOString().split('T')[0],
      message: suggestion,
    });

    setIsSuggestionDialogOpen(false);
    setSuggestion('');
    toast.success('Suggestion sent to patient');
  };

  // Reset form fields
  const resetFormFields = () => {
    setDiagnosis('');
    setPrescription('');
    setNotes('');
    setSuggestion('');
  };

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-800">Patient Management</h1>
        <p className="text-gray-600">Manage your patients and appointments</p>
      </div>

      <Tabs defaultValue="all">
        <TabsList className="mb-6">
          <TabsTrigger value="all">All Patients</TabsTrigger>
          <TabsTrigger value="today">Today's Appointments</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all">
          <Card className="dashboard-card">
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Users className="h-6 w-6 text-hospital-purple" />
                  <CardTitle>Your Patients</CardTitle>
                </div>
                <div className="w-64">
                  <Input 
                    placeholder="Search patients..." 
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Patient ID</TableHead>
                    <TableHead>Appointments</TableHead>
                    <TableHead>Last Visit</TableHead>
                    <TableHead>Next Appointment</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPatients.length > 0 ? (
                    filteredPatients.map(patient => (
                      <TableRow key={patient.id}>
                        <TableCell className="font-medium">Patient #{patient.id}</TableCell>
                        <TableCell>{patient.appointmentCount}</TableCell>
                        <TableCell>{patient.lastVisit}</TableCell>
                        <TableCell>{patient.nextAppointment}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedPatientId(patient.id);
                                setIsRecordDialogOpen(true);
                              }}
                            >
                              Add Record
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedPatientId(patient.id);
                                setIsSuggestionDialogOpen(true);
                              }}
                            >
                              Send Suggestion
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={5} className="text-center py-4">
                        {searchTerm ? 'No patients matching your search' : 'No patients found'}
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="today">
          <Card className="dashboard-card">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-3">
                <Calendar className="h-6 w-6 text-hospital-purple" />
                <CardTitle>Today's Appointments</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              {todayAppointments.length > 0 ? (
                <div className="space-y-4">
                  {todayAppointments.map(appointment => (
                    <div key={appointment.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <h3 className="font-medium">Patient #{appointment.patientId}</h3>
                          <p className="text-sm text-gray-500">{appointment.time}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setSelectedPatientId(appointment.patientId);
                              setIsRecordDialogOpen(true);
                            }}
                          >
                            Add Record
                          </Button>
                          <Button
                            size="sm"
                            className="hospital-btn-primary"
                            onClick={() => completeAppointment(appointment.id)}
                          >
                            Complete
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <h3 className="font-medium text-xl mb-2">No appointments for today</h3>
                  <p className="text-gray-500">You have no scheduled appointments for today.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      {/* Add Health Record Dialog */}
      <Dialog open={isRecordDialogOpen} onOpenChange={setIsRecordDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add Health Record</DialogTitle>
            <DialogDescription>
              Create a new health record for Patient #{selectedPatientId}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label htmlFor="diagnosis" className="text-sm font-medium">
                Diagnosis*
              </label>
              <Input
                id="diagnosis"
                value={diagnosis}
                onChange={(e) => setDiagnosis(e.target.value)}
                placeholder="Enter diagnosis"
                required
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="prescription" className="text-sm font-medium">
                Prescription
              </label>
              <Textarea
                id="prescription"
                value={prescription}
                onChange={(e) => setPrescription(e.target.value)}
                placeholder="Enter prescription details"
                rows={3}
              />
            </div>
            
            <div className="space-y-2">
              <label htmlFor="notes" className="text-sm font-medium">
                Notes
              </label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Enter any additional notes"
                rows={3}
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsRecordDialogOpen(false)}>
              Cancel
            </Button>
            <Button type="button" className="hospital-btn-primary" onClick={handleAddRecord}>
              Save Record
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Add Suggestion Dialog */}
      <Dialog open={isSuggestionDialogOpen} onOpenChange={setIsSuggestionDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Send Suggestion</DialogTitle>
            <DialogDescription>
              Send a medical suggestion to Patient #{selectedPatientId}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label htmlFor="suggestion" className="text-sm font-medium">
                Suggestion Message*
              </label>
              <Textarea
                id="suggestion"
                value={suggestion}
                onChange={(e) => setSuggestion(e.target.value)}
                placeholder="Enter your medical advice or suggestion"
                rows={5}
                required
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setIsSuggestionDialogOpen(false)}>
              Cancel
            </Button>
            <Button type="button" className="hospital-btn-primary" onClick={handleAddSuggestion}>
              Send Suggestion
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </DashboardLayout>
  );
};

export default Patients;
