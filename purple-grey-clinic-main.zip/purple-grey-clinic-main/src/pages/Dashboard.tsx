
import React from 'react';
import { useAuth } from '@/context/AuthContext';
import { useHospitalData } from '@/context/HospitalDataContext';
import DashboardLayout from '@/components/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar, Clock, FileText, User, Users, Hospital } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const { user } = useAuth();
  const { appointments, healthRecords, doctors } = useHospitalData();
  const navigate = useNavigate();

  if (!user) {
    return null; // This should be handled by DashboardLayout, but just in case
  }

  // Filter data based on user role
  const userAppointments = user.role === 'patient'
    ? appointments.filter(app => app.patientId === user.id)
    : user.role === 'doctor'
      ? appointments.filter(app => app.doctorId === user.id)
      : appointments;

  const userHealthRecords = user.role === 'patient'
    ? healthRecords.filter(record => record.patientId === user.id)
    : user.role === 'doctor'
      ? healthRecords.filter(record => record.doctorId === user.id)
      : healthRecords;

  // Define dashboard content based on user role
  const renderDashboardContent = () => {
    if (user.role === 'patient') {
      return (
        <>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card className="dashboard-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-hospital-purple" />
                  <span>Upcoming Appointments</span>
                </CardTitle>
                <CardDescription>Your scheduled appointments</CardDescription>
              </CardHeader>
              <CardContent>
                {userAppointments.length > 0 ? (
                  <div className="space-y-3">
                    {userAppointments.map(app => {
                      const doctor = doctors.find(d => d.id === app.doctorId);
                      return (
                        <div key={app.id} className="border-b pb-2">
                          <p className="font-medium">{doctor?.name}</p>
                          <div className="flex justify-between text-sm text-gray-600">
                            <span>{app.date}</span>
                            <span>{app.time}</span>
                          </div>
                          <div className="mt-1 flex justify-between items-center">
                            <span className={`text-xs px-2 py-1 rounded-full ${
                              app.status === 'scheduled' ? 'bg-blue-100 text-blue-800' :
                              app.status === 'completed' ? 'bg-green-100 text-green-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {app.status.charAt(0).toUpperCase() + app.status.slice(1)}
                            </span>
                            <span className={`text-xs px-2 py-1 rounded-full ${
                              app.paymentStatus === 'paid' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                            }`}>
                              {app.paymentStatus === 'paid' ? 'Paid' : 'Payment Pending'}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-gray-500">No upcoming appointments</p>
                )}
                <Button 
                  onClick={() => navigate('/dashboard/appointments')}
                  className="w-full mt-4 hospital-btn-primary"
                >
                  Book Appointment
                </Button>
              </CardContent>
            </Card>

            <Card className="dashboard-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium flex items-center gap-2">
                  <FileText className="h-5 w-5 text-hospital-purple" />
                  <span>Health Records</span>
                </CardTitle>
                <CardDescription>Your recent health records</CardDescription>
              </CardHeader>
              <CardContent>
                {userHealthRecords.length > 0 ? (
                  <div className="space-y-3">
                    {userHealthRecords.map(record => {
                      const doctor = doctors.find(d => d.id === record.doctorId);
                      return (
                        <div key={record.id} className="border-b pb-2">
                          <p className="font-medium">{record.diagnosis}</p>
                          <p className="text-sm text-gray-600">Dr: {doctor?.name}</p>
                          <p className="text-xs text-gray-500">{record.date}</p>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-gray-500">No health records available</p>
                )}
                <Button 
                  onClick={() => navigate('/dashboard/health-records')}
                  className="w-full mt-4 hospital-btn-primary"
                >
                  View All Records
                </Button>
              </CardContent>
            </Card>

            <Card className="dashboard-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium flex items-center gap-2">
                  <User className="h-5 w-5 text-hospital-purple" />
                  <span>Find a Doctor</span>
                </CardTitle>
                <CardDescription>Book an appointment with a specialist</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {doctors.slice(0, 3).map(doctor => (
                    <div key={doctor.id} className="flex items-center gap-3 border-b pb-2">
                      <div className="w-10 h-10 rounded-full bg-gray-100 overflow-hidden">
                        <img 
                          src={doctor.image} 
                          alt={doctor.name}
                          className="w-full h-full object-cover" 
                        />
                      </div>
                      <div>
                        <p className="font-medium">{doctor.name}</p>
                        <p className="text-xs text-gray-500">{doctor.specialization}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <Button 
                  onClick={() => navigate('/dashboard/appointments')}
                  className="w-full mt-4 hospital-btn-primary"
                >
                  View All Doctors
                </Button>
              </CardContent>
            </Card>
          </div>
        </>
      );
    } else if (user.role === 'doctor') {
      return (
        <>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card className="dashboard-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-hospital-purple" />
                  <span>Today's Appointments</span>
                </CardTitle>
                <CardDescription>Upcoming patient visits</CardDescription>
              </CardHeader>
              <CardContent>
                {userAppointments.length > 0 ? (
                  <div className="space-y-3">
                    {userAppointments.slice(0, 3).map(app => (
                      <div key={app.id} className="border-b pb-2">
                        <p className="font-medium">Patient #{app.patientId}</p>
                        <div className="flex justify-between text-sm text-gray-600">
                          <span>{app.date}</span>
                          <span>{app.time}</span>
                        </div>
                        <div className="mt-1">
                          <span className={`text-xs px-2 py-1 rounded-full ${
                            app.status === 'scheduled' ? 'bg-blue-100 text-blue-800' :
                            app.status === 'completed' ? 'bg-green-100 text-green-800' :
                            'bg-red-100 text-red-800'
                          }`}>
                            {app.status.charAt(0).toUpperCase() + app.status.slice(1)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">No appointments scheduled</p>
                )}
                <Button 
                  onClick={() => navigate('/dashboard/patients')}
                  className="w-full mt-4 hospital-btn-primary"
                >
                  View All Appointments
                </Button>
              </CardContent>
            </Card>

            <Card className="dashboard-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium flex items-center gap-2">
                  <Users className="h-5 w-5 text-hospital-purple" />
                  <span>My Patients</span>
                </CardTitle>
                <CardDescription>Your assigned patients</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="border-b pb-2">
                    <p className="font-medium">Total Patients</p>
                    <p className="text-2xl font-bold text-hospital-purple">
                      {userAppointments.reduce((acc, curr) => {
                        if (!acc.includes(curr.patientId)) {
                          acc.push(curr.patientId);
                        }
                        return acc;
                      }, [] as string[]).length}
                    </p>
                  </div>
                  <div className="border-b pb-2">
                    <p className="font-medium">Appointments This Week</p>
                    <p className="text-2xl font-bold text-hospital-purple">{userAppointments.length}</p>
                  </div>
                </div>
                <Button 
                  onClick={() => navigate('/dashboard/patients')}
                  className="w-full mt-4 hospital-btn-primary"
                >
                  Manage Patients
                </Button>
              </CardContent>
            </Card>

            <Card className="dashboard-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium flex items-center gap-2">
                  <Clock className="h-5 w-5 text-hospital-purple" />
                  <span>My Schedule</span>
                </CardTitle>
                <CardDescription>Your shift timings</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {['Monday', 'Wednesday', 'Friday'].map((day, i) => (
                    <div key={i} className="border-b pb-2">
                      <p className="font-medium">{day}</p>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {['9:00 AM - 12:00 PM', '2:00 PM - 5:00 PM'].map((time, j) => (
                          <span key={j} className="text-xs bg-hospital-softgrey px-2 py-1 rounded">
                            {time}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
                <Button 
                  onClick={() => navigate('/dashboard/shifts')}
                  className="w-full mt-4 hospital-btn-primary"
                >
                  Manage Schedule
                </Button>
              </CardContent>
            </Card>
          </div>
        </>
      );
    } else if (user.role === 'admin') {
      return (
        <>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card className="dashboard-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium flex items-center gap-2">
                  <Hospital className="h-5 w-5 text-hospital-purple" />
                  <span>Hospital Overview</span>
                </CardTitle>
                <CardDescription>Key metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="border-b pb-2">
                    <p className="font-medium">Total Doctors</p>
                    <p className="text-2xl font-bold text-hospital-purple">{doctors.length}</p>
                  </div>
                  <div className="border-b pb-2">
                    <p className="font-medium">Total Patients</p>
                    <p className="text-2xl font-bold text-hospital-purple">1</p>
                  </div>
                  <div className="border-b pb-2">
                    <p className="font-medium">Total Appointments</p>
                    <p className="text-2xl font-bold text-hospital-purple">{appointments.length}</p>
                  </div>
                </div>
                <Button 
                  onClick={() => navigate('/dashboard/management')}
                  className="w-full mt-4 hospital-btn-primary"
                >
                  View Full Report
                </Button>
              </CardContent>
            </Card>

            <Card className="dashboard-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium flex items-center gap-2">
                  <Users className="h-5 w-5 text-hospital-purple" />
                  <span>User Management</span>
                </CardTitle>
                <CardDescription>Manage system users</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between border-b pb-2">
                    <p className="font-medium">Doctors</p>
                    <Button variant="outline" size="sm">Manage</Button>
                  </div>
                  <div className="flex items-center justify-between border-b pb-2">
                    <p className="font-medium">Patients</p>
                    <Button variant="outline" size="sm">Manage</Button>
                  </div>
                  <div className="flex items-center justify-between border-b pb-2">
                    <p className="font-medium">Admins</p>
                    <Button variant="outline" size="sm">Manage</Button>
                  </div>
                </div>
                <Button 
                  onClick={() => navigate('/dashboard/users')}
                  className="w-full mt-4 hospital-btn-primary"
                >
                  User Management
                </Button>
              </CardContent>
            </Card>

            <Card className="dashboard-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg font-medium flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-hospital-purple" />
                  <span>Appointments</span>
                </CardTitle>
                <CardDescription>All hospital appointments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="border-b pb-2">
                    <p className="font-medium">Today</p>
                    <p className="text-2xl font-bold text-hospital-purple">5</p>
                  </div>
                  <div className="border-b pb-2">
                    <p className="font-medium">This Week</p>
                    <p className="text-2xl font-bold text-hospital-purple">24</p>
                  </div>
                  <div className="border-b pb-2">
                    <p className="font-medium">This Month</p>
                    <p className="text-2xl font-bold text-hospital-purple">87</p>
                  </div>
                </div>
                <Button 
                  onClick={() => navigate('/dashboard/management')}
                  className="w-full mt-4 hospital-btn-primary"
                >
                  View All Appointments
                </Button>
              </CardContent>
            </Card>
          </div>
        </>
      );
    }

    return <div>Dashboard content not available</div>;
  };

  return (
    <DashboardLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-800">
          Welcome back, {user.name.split(' ')[0]}
        </h1>
        <p className="text-gray-600">
          Here's what's happening with your {user.role === 'patient' ? 'health' : user.role === 'doctor' ? 'patients' : 'hospital'} today.
        </p>
      </div>
      
      {renderDashboardContent()}
    </DashboardLayout>
  );
};

export default Dashboard;
