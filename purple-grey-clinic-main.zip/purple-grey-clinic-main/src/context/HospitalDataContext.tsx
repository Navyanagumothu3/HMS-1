
import React, { createContext, useState, useContext, ReactNode } from 'react';

// Define our data types
export interface Doctor {
  id: string;
  name: string;
  specialization: string;
  experience: number;
  fee: number;
  availability: { day: string; slots: string[] }[];
  image: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  doctorId: string;
  date: string;
  time: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  paymentStatus: 'pending' | 'paid';
  fee: number;
}

export interface HealthRecord {
  id: string;
  patientId: string;
  doctorId: string;
  date: string;
  diagnosis: string;
  prescription: string;
  notes: string;
}

export interface DoctorSuggestion {
  id: string;
  patientId: string;
  doctorId: string;
  date: string;
  message: string;
}

interface HospitalDataContextType {
  doctors: Doctor[];
  appointments: Appointment[];
  healthRecords: HealthRecord[];
  suggestions: DoctorSuggestion[];
  addAppointment: (appointment: Omit<Appointment, 'id'>) => void;
  updateAppointmentStatus: (id: string, status: 'scheduled' | 'completed' | 'cancelled') => void;
  updatePaymentStatus: (id: string, status: 'pending' | 'paid') => void;
  addHealthRecord: (record: Omit<HealthRecord, 'id'>) => void;
  addSuggestion: (suggestion: Omit<DoctorSuggestion, 'id'>) => void;
}

// Create mock data
const mockDoctors: Doctor[] = [
  {
    id: '1',
    name: 'Dr. Jane Smith',
    specialization: 'Cardiology',
    experience: 10,
    fee: 150,
    availability: [
      { day: 'Monday', slots: ['10:00 AM', '11:00 AM', '2:00 PM', '3:00 PM'] },
      { day: 'Wednesday', slots: ['9:00 AM', '10:00 AM', '1:00 PM', '2:00 PM'] },
      { day: 'Friday', slots: ['11:00 AM', '12:00 PM', '3:00 PM', '4:00 PM'] },
    ],
    image: 'https://randomuser.me/api/portraits/women/65.jpg',
  },
  {
    id: '2',
    name: 'Dr. Robert Johnson',
    specialization: 'Neurology',
    experience: 15,
    fee: 200,
    availability: [
      { day: 'Tuesday', slots: ['9:00 AM', '10:00 AM', '2:00 PM', '3:00 PM'] },
      { day: 'Thursday', slots: ['10:00 AM', '11:00 AM', '1:00 PM', '2:00 PM'] },
      { day: 'Saturday', slots: ['10:00 AM', '11:00 AM', '12:00 PM', '1:00 PM'] },
    ],
    image: 'https://randomuser.me/api/portraits/men/32.jpg',
  },
  {
    id: '3',
    name: 'Dr. Sarah Chen',
    specialization: 'Dermatology',
    experience: 8,
    fee: 175,
    availability: [
      { day: 'Monday', slots: ['9:00 AM', '10:00 AM', '1:00 PM', '2:00 PM'] },
      { day: 'Wednesday', slots: ['11:00 AM', '12:00 PM', '3:00 PM', '4:00 PM'] },
      { day: 'Friday', slots: ['10:00 AM', '11:00 AM', '2:00 PM', '3:00 PM'] },
    ],
    image: 'https://randomuser.me/api/portraits/women/33.jpg',
  },
];

const mockAppointments: Appointment[] = [
  {
    id: '1',
    patientId: '1',
    doctorId: '1',
    date: '2025-05-15',
    time: '10:00 AM',
    status: 'scheduled',
    paymentStatus: 'paid',
    fee: 150,
  },
  {
    id: '2',
    patientId: '1',
    doctorId: '2',
    date: '2025-05-20',
    time: '11:00 AM',
    status: 'scheduled',
    paymentStatus: 'pending',
    fee: 200,
  },
];

const mockHealthRecords: HealthRecord[] = [
  {
    id: '1',
    patientId: '1',
    doctorId: '1',
    date: '2025-05-01',
    diagnosis: 'Hypertension',
    prescription: 'Lisinopril 10mg daily',
    notes: 'Blood pressure readings consistently high. Recommended lifestyle changes and medication.',
  },
];

const mockSuggestions: DoctorSuggestion[] = [
  {
    id: '1',
    patientId: '1',
    doctorId: '1',
    date: '2025-05-05',
    message: 'Please remember to take your medication daily and monitor your blood pressure twice a week.',
  },
];

// Create the context
const HospitalDataContext = createContext<HospitalDataContextType | undefined>(undefined);

export const HospitalDataProvider = ({ children }: { children: ReactNode }) => {
  const [doctors] = useState<Doctor[]>(mockDoctors);
  const [appointments, setAppointments] = useState<Appointment[]>(mockAppointments);
  const [healthRecords, setHealthRecords] = useState<HealthRecord[]>(mockHealthRecords);
  const [suggestions, setSuggestions] = useState<DoctorSuggestion[]>(mockSuggestions);

  const addAppointment = (appointment: Omit<Appointment, 'id'>) => {
    const newAppointment = {
      ...appointment,
      id: `${appointments.length + 1}`,
    };
    setAppointments([...appointments, newAppointment]);
  };

  const updateAppointmentStatus = (id: string, status: 'scheduled' | 'completed' | 'cancelled') => {
    setAppointments(
      appointments.map((appointment) =>
        appointment.id === id ? { ...appointment, status } : appointment
      )
    );
  };

  const updatePaymentStatus = (id: string, status: 'pending' | 'paid') => {
    setAppointments(
      appointments.map((appointment) =>
        appointment.id === id ? { ...appointment, paymentStatus: status } : appointment
      )
    );
  };

  const addHealthRecord = (record: Omit<HealthRecord, 'id'>) => {
    const newRecord = {
      ...record,
      id: `${healthRecords.length + 1}`,
    };
    setHealthRecords([...healthRecords, newRecord]);
  };

  const addSuggestion = (suggestion: Omit<DoctorSuggestion, 'id'>) => {
    const newSuggestion = {
      ...suggestion,
      id: `${suggestions.length + 1}`,
    };
    setSuggestions([...suggestions, newSuggestion]);
  };

  return (
    <HospitalDataContext.Provider
      value={{
        doctors,
        appointments,
        healthRecords,
        suggestions,
        addAppointment,
        updateAppointmentStatus,
        updatePaymentStatus,
        addHealthRecord,
        addSuggestion,
      }}
    >
      {children}
    </HospitalDataContext.Provider>
  );
};

// Custom hook to use hospital data context
export const useHospitalData = () => {
  const context = useContext(HospitalDataContext);
  if (context === undefined) {
    throw new Error('useHospitalData must be used within a HospitalDataProvider');
  }
  return context;
};
