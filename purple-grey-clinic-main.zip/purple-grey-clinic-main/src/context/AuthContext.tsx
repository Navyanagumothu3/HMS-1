
import React, { createContext, useState, useContext, ReactNode } from 'react';

// Define our user types
export type UserRole = 'patient' | 'doctor' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  signup: (name: string, email: string, password: string, role: UserRole) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

// Create the context
const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock user data
const mockUsers = [
  { id: '1', name: 'John Patient', email: 'patient@example.com', password: 'password', role: 'patient' as UserRole },
  { id: '2', name: 'Dr. Jane Smith', email: 'doctor@example.com', password: 'password', role: 'doctor' as UserRole },
  { id: '3', name: 'Admin User', email: 'admin@example.com', password: 'password', role: 'admin' as UserRole },
];

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);

  // Check if there's a saved user in localStorage on initial load
  React.useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const login = async (email: string, password: string) => {
    // Simulate API call with a delay
    return new Promise<void>((resolve, reject) => {
      setTimeout(() => {
        const foundUser = mockUsers.find(
          (u) => u.email === email && u.password === password
        );
        
        if (foundUser) {
          const { password, ...userWithoutPassword } = foundUser;
          setUser(userWithoutPassword);
          localStorage.setItem('user', JSON.stringify(userWithoutPassword));
          resolve();
        } else {
          reject(new Error('Invalid email or password'));
        }
      }, 500);
    });
  };

  const signup = async (name: string, email: string, password: string, role: UserRole) => {
    // Simulate API call with a delay
    return new Promise<void>((resolve, reject) => {
      setTimeout(() => {
        // Check if user already exists
        const existingUser = mockUsers.find((u) => u.email === email);
        if (existingUser) {
          reject(new Error('User with this email already exists'));
          return;
        }

        // In a real app, we would save this to a database
        const newUser = {
          id: `${mockUsers.length + 1}`,
          name,
          email,
          password,
          role,
        };
        
        // Add to mock users (in a real app this would be saving to database)
        mockUsers.push(newUser);
        
        // Set the current user (without the password)
        const { password: _, ...userWithoutPassword } = newUser;
        setUser(userWithoutPassword);
        
        // Save to localStorage for persistence
        localStorage.setItem('user', JSON.stringify(userWithoutPassword));
        
        resolve();
      }, 500);
    });
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to use auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
