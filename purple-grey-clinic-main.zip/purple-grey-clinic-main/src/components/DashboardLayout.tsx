
import React, { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import Navbar from '@/components/Navbar';
import { User, Calendar, BookOpen, Clock, Users, Hospital, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface DashboardLayoutProps {
  children: ReactNode;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  const { user } = useAuth();
  const navigate = useNavigate();

  if (!user) {
    // Redirect to login page if not authenticated
    navigate('/login');
    return null;
  }

  // Define menu items based on user role
  const getMenuItems = () => {
    const commonItems = [
      { icon: User, label: 'Profile', href: '/profile' },
    ];

    if (user.role === 'patient') {
      return [
        ...commonItems,
        { icon: Calendar, label: 'Appointments', href: '/dashboard/appointments' },
        { icon: FileText, label: 'Health Records', href: '/dashboard/health-records' },
        { icon: BookOpen, label: 'Doctor Suggestions', href: '/dashboard/suggestions' },
      ];
    } else if (user.role === 'doctor') {
      return [
        ...commonItems,
        { icon: Users, label: 'My Patients', href: '/dashboard/patients' },
        { icon: Clock, label: 'Shift Timings', href: '/dashboard/shifts' },
      ];
    } else if (user.role === 'admin') {
      return [
        ...commonItems,
        { icon: Hospital, label: 'Hospital Management', href: '/dashboard/management' },
        { icon: Users, label: 'Users', href: '/dashboard/users' },
      ];
    }

    return commonItems;
  };

  const menuItems = getMenuItems();

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="pt-[72px] flex flex-1">
        {/* Sidebar */}
        <aside className="w-[80px] md:w-64 bg-white/80 backdrop-blur-sm border-r border-gray-200 h-[calc(100vh-72px)] fixed">
          <div className="flex flex-col p-4 h-full">
            {/* User Info */}
            <div className="mb-8 text-center">
              <div className="h-16 w-16 rounded-full bg-hospital-purple text-white flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold">{user.name.charAt(0)}</span>
              </div>
              <div className="hidden md:block mt-2">
                <p className="font-semibold text-gray-800">{user.name}</p>
                <p className="text-xs text-gray-500 capitalize">{user.role}</p>
              </div>
            </div>

            {/* Navigation */}
            <nav className="flex-1">
              <ul className="space-y-2">
                {menuItems.map((item, index) => (
                  <li key={index}>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            className="w-full justify-start"
                            onClick={() => navigate(item.href)}
                          >
                            <item.icon className="h-5 w-5 md:mr-2" />
                            <span className="hidden md:inline">{item.label}</span>
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent side="right" className="md:hidden">
                          {item.label}
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  </li>
                ))}
              </ul>
            </nav>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 ml-[80px] md:ml-64 p-6">
          {children}
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;
