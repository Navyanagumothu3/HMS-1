
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { User, LogOut, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const Navbar = () => {
  const { user, logout } = useAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
  };

  return (
    <nav className="bg-white/80 backdrop-blur-sm border-b border-gray-200 py-4 px-6 fixed top-0 left-0 right-0 z-50">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="flex items-center gap-2">
          <div className="bg-hospital-purple text-white p-2 rounded-md">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold text-gray-800">MedCare</h1>
        </Link>

        {/* Mobile menu button */}
        <div className="md:hidden">
          <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </Button>
        </div>

        {/* Desktop navigation */}
        <div className="hidden md:flex items-center gap-4">
          {user && (
            <>
              <Link to="/dashboard" className="text-gray-700 hover:text-hospital-purple transition-colors">
                Dashboard
              </Link>
              <div className="relative group">
                <button className="flex items-center gap-1 text-gray-700 hover:text-hospital-purple transition-colors">
                  <User size={18} />
                  <span>{user.name}</span>
                </button>
              </div>
              <Button onClick={handleLogout} variant="ghost" className="flex items-center gap-1">
                <LogOut size={18} />
                <span>Logout</span>
              </Button>
            </>
          )}
          {!user && (
            <>
              <Link to="/login" className="text-gray-700 hover:text-hospital-purple transition-colors">
                Login
              </Link>
              <Link to="/signup">
                <Button className="hospital-btn-primary">Sign Up</Button>
              </Link>
            </>
          )}
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden absolute top-full left-0 right-0 bg-white shadow-lg border-b border-gray-200 py-4 px-6 flex flex-col gap-4">
            {user ? (
              <>
                <Link 
                  to="/dashboard" 
                  className="text-gray-700 hover:text-hospital-purple transition-colors py-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Dashboard
                </Link>
                <div className="text-gray-700 py-2 flex items-center gap-1">
                  <User size={18} />
                  <span>{user.name}</span>
                </div>
                <button 
                  onClick={handleLogout}
                  className="text-red-600 hover:text-red-800 transition-colors flex items-center gap-1 py-2"
                >
                  <LogOut size={18} />
                  <span>Logout</span>
                </button>
              </>
            ) : (
              <>
                <Link 
                  to="/login" 
                  className="text-gray-700 hover:text-hospital-purple transition-colors py-2"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Login
                </Link>
                <Link 
                  to="/signup"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <Button className="hospital-btn-primary w-full">Sign Up</Button>
                </Link>
              </>
            )}
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
